from .RobotAxeLibrary import RobotAxeLibrary

def main():
    lib = RobotAxeLibrary()

if __name__ == '__main__':
    main()