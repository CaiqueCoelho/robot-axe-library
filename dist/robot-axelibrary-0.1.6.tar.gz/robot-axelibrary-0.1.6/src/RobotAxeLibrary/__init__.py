from RobotAxeLibrary import RobotAxeLibrary

def main():
    lib = RobotAxeLibrary()
    lib.helloA11y()
    return lib

if __name__ == '__main__':
    main()