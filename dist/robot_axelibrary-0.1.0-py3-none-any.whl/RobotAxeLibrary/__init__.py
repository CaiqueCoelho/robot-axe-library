from RobotAxeLibrary import RobotAxeLibrary

def main():
    lib = RobotAxeLibrary()
    lib.helloA11y()

if __name__ == '__main__':
    main()